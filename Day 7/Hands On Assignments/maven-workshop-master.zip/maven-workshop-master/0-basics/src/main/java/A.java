public class A {
    final private int a;

    public A(int v) {
        a = v;
    }

    int get() {
        return a;
    }
}
